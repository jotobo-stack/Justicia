export default function About() {
  return (
    <main style={{padding:'2rem', fontFamily:'sans-serif'}}>
      <h1>About Justicia</h1>
      <p>Warm and approachable professional dedicated to research, education, and strategic leadership.</p>
    </main>
  );
}