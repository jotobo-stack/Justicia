'use client'
import React, { useState } from 'react'
import Link from 'next/link'
import { Sun, Moon, ArrowRight, Mail, MapPin } from 'lucide-react'

const SITE = {
  name: process.env.NEXT_PUBLIC_SITE_NAME || 'Justicia',
  tagline: process.env.NEXT_PUBLIC_TAGLINE || 'Experienced Project Management Professional, Researcher, Author and Educator.',
  location: process.env.NEXT_PUBLIC_LOCATION || 'London, UK',
  email: process.env.NEXT_PUBLIC_EMAIL || 'info@jotobo.com',
  linkedin: process.env.NEXT_PUBLIC_LINKEDIN || 'https://www.linkedin.com/in/jotobo',
  services: [
    { title: 'Project & Programme Consultation', desc: 'Set-up, audits, PMO support, delivery reviews, and recovery planning.' },
    { title: 'Masterclass Facilitation', desc: 'Interactive sessions on delivery frameworks, stakeholder management, and risk.' },
    { title: 'Leadership Workshops', desc: 'Team and executive workshops focused on decision-making and communication.' },
    { title: 'Research & Thought Leadership', desc: 'Qualitative/quantitative research, whitepapers, playbooks, and speaking.' },
    { title: 'Strategic Planning & Execution', desc: 'Planning, prioritisation, roadmap development and delivery alignment.' },
    { title: 'Research Support & Analysis', desc: 'Evidence gathering, insights, synthesis and reporting.' },
    { title: 'Training & Capacity Building', desc: 'Capability uplift, skills development and structured learning programmes.' }
  ],
  projects: [
    { title: 'Project Recovery (Example)', blurb: 'Recovered a troubled programme, delivering milestones on time.', tags: ['Consulting'], link: '#' },
    { title: 'Leadership Series', blurb: 'Delivered a cohort-based masterclass for senior leaders.', tags: ['Training'], link: '#' }
  ],
  posts: [
    { title: 'Launching a Portfolio That Converts', date: '2025-08-20', excerpt: 'My checklist for turning a personal site into a lead-gen engine.' },
    { title: 'Writing Case Studies People Actually Read', date: '2025-05-14', excerpt: 'Cut the fluff, show decisions, and quantify outcomes—here’s my template.' }
  ]
}

export default function Home() {
  const [dark, setDark] = useState(true)
  return (
    <div className={dark ? 'dark' : ''}>
      <div className='min-h-screen bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100'>
        <header className='border-b bg-white/70 dark:bg-black/40 backdrop-blur sticky top-0 z-50'>
          <div className='mx-auto max-w-6xl px-4 py-4 flex items-center justify-between'>
            <div className='font-semibold'>{SITE.name}</div>
            <div className='flex items-center gap-3'>
              <a href='#services' className='text-sm'>Services</a>
              <a href='#work' className='text-sm'>Work</a>
              <a href='#blog' className='text-sm'>Blog</a>
              <button onClick={() => setDark(d => !d)} className='rounded p-2 border'>
                {dark ? <Sun className='w-4 h-4' /> : <Moon className='w-4 h-4' />}
              </button>
            </div>
          </div>
        </header>

        <main className='mx-auto max-w-6xl px-4 py-12'>
          <section id='home' className='grid lg:grid-cols-12 gap-8 items-center'>
            <div className='lg:col-span-7'>
              <div className='inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs mb-3'>Available for consulting</div>
              <h1 className='text-3xl sm:text-5xl font-semibold'>{SITE.tagline}</h1>
              <p className='mt-4 text-zinc-600 dark:text-zinc-300 max-w-2xl'>I help organisations deliver outcomes through rigorous project & programme practice, practical research, and leadership education. I run workshops, design masterclasses, and provide hands-on consultation to get things moving.</p>
              <div className='mt-6 flex gap-3'>
                <a href='#work' className='inline-flex items-center gap-2 rounded-2xl border px-4 py-2'>View work <ArrowRight className='w-4 h-4' /></a>
                <a href='#contact' className='inline-flex items-center gap-2 rounded-2xl border px-4 py-2'>Contact</a>
              </div>

              <div className='mt-6 flex items-center gap-4 text-sm text-zinc-600 dark:text-zinc-300'>
                <span className='inline-flex items-center gap-2'><MapPin className='w-4 h-4' />{SITE.location}</span>
                <a className='inline-flex items-center gap-2' href={`mailto:${SITE.email}`}><Mail className='w-4 h-4' />{SITE.email}</a>
              </div>

              <div className='mt-6'>
                <a href={SITE.linkedin} target='_blank' rel='noreferrer' className='text-sm underline'>LinkedIn</a>
              </div>
            </div>
            <div className='lg:col-span-5'>
              <div className='rounded-2xl border overflow-hidden'>
                <img src='/profile.jpg' alt='Profile' className='w-full h-72 object-cover' />
              </div>
            </div>
          </section>

          <section id='services' className='mt-12'>
            <h2 className='text-2xl font-semibold mb-4'>Services</h2>
            <div className='grid md:grid-cols-2 lg:grid-cols-4 gap-6'>
              {SITE.services.map(s => (
                <div key={s.title} className='rounded-2xl border p-5 bg-white/60 dark:bg-zinc-900/60'>
                  <h3 className='font-semibold'>{s.title}</h3>
                  <p className='text-sm mt-2 text-zinc-600 dark:text-zinc-300'>{s.desc}</p>
                </div>
              ))}
            </div>
          </section>

          <section id='work' className='mt-12'>
            <h2 className='text-2xl font-semibold mb-4'>Selected Work</h2>
            <div className='grid md:grid-cols-2 gap-6'>
              {SITE.projects.map(p => (
                <a key={p.title} href={p.link} className='group'>
                  <div className='rounded-2xl border overflow-hidden'>
                    <div className='p-5'>
                      <h3 className='font-semibold'>{p.title}</h3>
                      <p className='text-sm mt-1 text-zinc-600 dark:text-zinc-300'>{p.blurb}</p>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </section>

          <section id='blog' className='mt-12'>
            <h2 className='text-2xl font-semibold mb-4'>Latest Posts</h2>
            <div className='grid md:grid-cols-3 gap-6'>
              {SITE.posts.map(post => (
                <article key={post.title} className='rounded-2xl border p-5'>
                  <h3 className='font-semibold'>{post.title}</h3>
                  <p className='text-xs text-zinc-500'>{new Date(post.date).toLocaleDateString()}</p>
                  <p className='text-sm mt-2 text-zinc-600 dark:text-zinc-300'>{post.excerpt}</p>
                </article>
              ))}
            </div>
          </section>

          <section id='about' className='mt-12'>
            <h2 className='text-2xl font-semibold mb-4'>About</h2>
            <div className='grid lg:grid-cols-12 gap-6'>
              <div className='lg:col-span-8'>
                <div className='rounded-2xl border p-6'>
                  <p className='text-sm text-zinc-700 dark:text-zinc-200'>Hi — I’m Justicia. I combine hands-on project delivery experience with research and teaching to help teams get measurable outcomes. I run workshops, write about practice, and work with leaders to build capability and clarity. My approach is practical, evidence-informed, and focused on getting results.</p>
                </div>
              </div>
              <div className='lg:col-span-4'>
                <div className='rounded-2xl border p-6'>
                  <h3 className='font-semibold'>Quick facts</h3>
                  <ul className='mt-3 text-sm space-y-2'>
                    <li>🎯 Focus: SMB programmes, non-profit, and education</li>
                    <li>🧰 Methods: PMO, Agile-adapted, mixed methods research</li>
                    <li>📍 Based in: {SITE.location}</li>
                    <li>📝 Available for consulting & facilitation</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section id='contact' className='mt-12'>
            <h2 className='text-2xl font-semibold mb-4'>Contact</h2>
            <div className='grid lg:grid-cols-12 gap-6'>
              <div className='lg:col-span-7'>
                <form name='contact' method='POST' data-netlify='true' className='rounded-2xl border p-6 grid gap-3' onSubmit={() => { /* Netlify will handle */ }}>
                  <input type='hidden' name='form-name' value='contact' />
                  <label className='text-sm'>Name<input name='name' required className='w-full rounded-xl border px-3 py-2 mt-1' /></label>
                  <label className='text-sm'>Email<input name='email' type='email' required className='w-full rounded-xl border px-3 py-2 mt-1' /></label>
                  <label className='text-sm'>Message<textarea name='message' rows='5' required className='w-full rounded-xl border px-3 py-2 mt-1' /></label>
                  <button type='submit' className='inline-flex items-center gap-2 rounded-2xl border px-4 py-2 w-max'>Send</button>
                </form>
              </div>
              <div className='lg:col-span-5'>
                <div className='rounded-2xl border p-6'>
                  <h3 className='font-semibold'>Prefer direct?</h3>
                  <div className='mt-3 text-sm'>
                    <a className='block' href={`mailto:${SITE.email}`}>{SITE.email}</a>
                    <a className='block' href={SITE.linkedin} target='_blank' rel='noreferrer'>LinkedIn</a>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <footer className='mt-12 border-t py-8 text-sm text-zinc-600 dark:text-zinc-300'>
            <div className='mx-auto max-w-6xl px-4'>
              <div className='flex items-center justify-between'>
                <div>© {new Date().getFullYear()} Justicia. All rights reserved.</div>
                <a href='#home' className='underline'>Back to top</a>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </div>
  )
}
