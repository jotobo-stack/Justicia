export default {
  output: 'export', // required to export static HTML
  images: { unoptimized: true }
};
